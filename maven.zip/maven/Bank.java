package com.maven;

class Bank_588 {
	//method to return interest rate
	double getInterestRate() {
		return 0;
	}
}
class SBI extends Bank_588{
	double getInterestRate() {
		return 6.5;
	}
}
class HDFC extends Bank_588{
	double getInterestRate() {
		return 7.0;
	}
}
public class Bank{
	public static void main(String args[]){
		 Bank_588 bank;

	        bank = new SBI();
	        System.out.println("SBI Interest Rate: " + bank.getInterestRate() + "%");

	        bank = new HDFC();
	        System.out.println("HDFC Interest Rate: " + bank.getInterestRate() + "%");
	}
}