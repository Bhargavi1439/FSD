package com.maven;
//Parent class
class BankAccount {
 protected String accountNumber;
 protected double balance;

 public BankAccount(String accountNumber, double balance) {
     this.accountNumber = accountNumber;
     this.balance = balance;
 }

 public void deposit(double amount) {
     balance += amount;
     System.out.println("Deposited: " + amount);
 }

 public void displayBalance() {
     System.out.println("Account Number: " + accountNumber);
     System.out.println("Balance: " + balance);
 }
}

//Child class
class SavingsAccount extends BankAccount {
 private double interestRate;   // in percentage

 public SavingsAccount(String accountNumber, double balance, double interestRate) {
     super(accountNumber, balance);   // calling parent constructor
     this.interestRate = interestRate;
 }

 public void calculateInterest() {
     double interest = balance * (interestRate / 100);
     System.out.println("Interest Earned: " + interest);
     balance += interest;
 }
}

public class InheritanceDemo {
 public static void main(String[] args) {
     SavingsAccount sa = new SavingsAccount("ACC123", 10000, 5); // 5% interest

     sa.displayBalance();
     sa.calculateInterest();
     sa.displayBalance();
 }
}
