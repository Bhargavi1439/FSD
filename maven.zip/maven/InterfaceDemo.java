package com.maven;
//interface
interface Drawable {
 void draw();
}

//implementing class Circle
class Circle implements Drawable {
 public void draw() {
     System.out.println("Drawing a Circle");
 }
}

//implementing class Rectangle
class Rectangle implements Drawable {
 public void draw() {
     System.out.println("Drawing a Rectangle");
 }
}

public class InterfaceDemo {
 public static void main(String[] args) {
     Drawable d1 = new Circle();
     Drawable d2 = new Rectangle();

     d1.draw();
     d2.draw();
 }
}
