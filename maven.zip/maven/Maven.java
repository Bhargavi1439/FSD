package com.maven;

public class Maven {
	public static void main(String args[]) {
		System.out.println("Hello Maven");
	}
}
